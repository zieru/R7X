<?php
/**
 * Created by PhpStorm.
 * User: darryl
 * Date: 10/8/2017
 * Time: 5:11 PM
 */

namespace App\Http\Controllers\Front;


use App\Http\Controllers\Controller;

abstract class FrontController extends Controller
{


}
